import os
import json
from groq import Groq
from dotenv import load_dotenv

load_dotenv()
client = Groq(api_key=os.getenv('GROQ_API_KEY'))

SYSTEM_PROMPT = """
You are an assistant who is in charge of converting instructions into JSON actions.
Supported actions:
- start_pomodoro(timer:int, rest_time:int=5, task_name:str)
- pause_pomodoro()
- resume_pomodoro()
- stop_pomodoro()

Answer just with a valid JSON file, without additional text.
Example:
{"action":"start_pomodoro","timer":25,"rest_time":10,"task_name":"study math"}
"""
def interpret_prompt(prompt: str) -> dict:
    completion = client.chat.completions.create(
        model="llama3-8b-8192",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0,
    )

    content = chat_completion.choices[0].message.content
    try:
        result = json.loads(content)
    except Exception:
        result = {"error": "I couldn`t understood the instruction", "raw": content}
