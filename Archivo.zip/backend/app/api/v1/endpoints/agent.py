from fastapi import APIRouter
from app.agents.groq_agent import interpret_prompt
from pydantic import BaseModel

router = APIRouter()

class PromptRequest(BaseModel):
    prompt: str

@router.post("/agent/")
def agent_endpoint(request: PromptRequest):
    return interpret_prompt(request.prompt)